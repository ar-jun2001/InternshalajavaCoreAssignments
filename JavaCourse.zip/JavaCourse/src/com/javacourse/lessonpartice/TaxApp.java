package com.javacourse.lessonpartice;

import java.util.Scanner;

public class TaxApp {
    public static long calculateTax(long personIncome) {
        if (personIncome >= 300000) {
            return (personIncome / 100) * 20;
        } else if (personIncome >= 100000) {
            return (personIncome / 100) * 10;
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {
        System.out.println("TAX CALCULATOR APP");
        System.out.println("------ WELCOME----");
        Scanner obj = new Scanner(System.in);
        System.out.println("Enter the total person count: ");
        int personCount = obj.nextInt();
        obj.nextLine();
        
        String personName[] = new String[personCount];
        long personIncome[] = new long[personCount];

        for (int i = 0; i < personName.length; i++) {
            System.out.println("Enter the name " + (i + 1) + ":");
            personName[i] = obj.nextLine();
            
            System.out.println("Enter " + personName[i] + "'s annual income:");
            personIncome[i] = obj.nextLong();
            obj.nextLine(); // Consume the newline character after reading the long
            
            System.out.println(personName[i] + "'s annual income: " + personIncome[i]);
        }
        System.out.println("Names with liable taxes");
        System.out.println("-------------");
        for (int i = 0; i < personName.length; i++) {
            long tax = calculateTax(personIncome[i]);
            System.out.println(personName[i] + "'s tax: " + tax);
        }
    }
}
