package com.javacourse.lessonpartice;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		Cake obj = new Cake("Chocolate Brownie" ,250.0);
		Cake obj1 = new Cake("Chocolate Maple" ,300.0);
		List <Cake>arrobj1 = new ArrayList();
		arrobj1.add(obj);
		arrobj1.add(obj1);
		
	
		Pastry pasobj1= new Pastry("Black Forest",  35.0);
		Pastry pasobj2 = new Pastry("Choco Truffle", 40.0);
			List<Pastry> arrobj2 = new ArrayList();
			arrobj2.add(pasobj1);
			arrobj2.add(pasobj2);
			System.out.println("   Today's Special Menu");
		System.out.println("-----------------------------");
			System.out.println("Special Cakes");
		System.out.println("-----------------------------");
		for(Cake cake : arrobj1) {
			cake.display();
			
		}System.out.println();
		    System.out.println("Special Pastries");
		System.out.println("-----------------------------");
		for(Pastry cake : arrobj2) {
			cake.display();
			
		}
		

		
	}

}
