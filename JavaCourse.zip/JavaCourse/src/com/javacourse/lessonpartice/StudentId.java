package com.javacourse.lessonpartice;

import java.util.Scanner;

public class StudentId {
	public static void main(String[] arj) {
		String studentName;
		int studentAge;
		String studentBloodGroup;

		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Student Name ");

		studentName = input.nextLine();
		System.out.println("Enter the Student Age ");
		studentAge = input.nextInt();
		System.out.println("Enter the Student BloodGroup ");
		studentBloodGroup = input.next();

		if (studentAge >= 20) {
			System.out.println("________________________________ ");
			System.out.println("Name : " + studentName);
			System.out.println("Age : " + studentAge);
			System.out.println("BloodGroup : " + studentBloodGroup);
			System.out.println("________________________________ ");
			System.out.println("You are RED Group");
			System.out.println("________________________________ ");
		} else if (studentAge >= 15 && studentAge < 20) {
			System.out.println("________________________________ ");
			System.out.println("Name : " + studentName);
			System.out.println("Age : " + studentAge);
			System.out.println("BloodGroup : " + studentBloodGroup);
			
			System.out.println("________________________________ ");
			System.out.println("You are BLUE Group");
			System.out.println("________________________________ ");
		} else if (studentAge >= 10 && studentAge < 15) {
			System.out.println("________________________________ ");
			System.out.println("Name : " + studentName);
			System.out.println("Age : " + studentAge);
			System.out.println("BloodGroup : " + studentBloodGroup);
			System.out.println("________________________________ ");
			System.out.println("You are YELLOW Group");
			System.out.println("________________________________ ");

		}

	}

}
