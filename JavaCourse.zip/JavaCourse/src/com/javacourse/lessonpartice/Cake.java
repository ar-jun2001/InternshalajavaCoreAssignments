package com.javacourse.lessonpartice;

public class Cake {
	private String cakeName;
	private double cakePrice;
	public void setCakeName(String cakeName) {
		this.cakeName = cakeName;
	}
	public double getCakePrice() {
		return cakePrice;
	}
	public void setCakePrice(int cakePrice) {
		this.cakePrice = cakePrice;
	}
	public String getCakeName() {
		return cakeName;
	}
	Cake(String cakeName,double cakePrice){
		this.cakeName = cakeName;
		this.cakePrice = cakePrice;
		
	}
	public void display() {
		System.out.println(cakeName+" : ₹"+cakePrice+" per pound");
	}
	
	
	

}
