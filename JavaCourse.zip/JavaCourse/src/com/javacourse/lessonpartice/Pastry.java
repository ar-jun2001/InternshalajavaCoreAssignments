package com.javacourse.lessonpartice;

public class Pastry extends Cake{
	
	
	Pastry(String cakeName, double cakePrice) {
		super(cakeName, cakePrice);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println(getCakeName()+":₹ "+getCakePrice()+" per price");
	}
}
